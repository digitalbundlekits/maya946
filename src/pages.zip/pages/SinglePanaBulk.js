import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../styles/SinglePanaBulk.css';
import { useNavigate, useParams, useLocation } from 'react-router-dom';

const SinglePanaBulk = () => {
    const [balance, setBalance] = useState(0);
    const [points, setPoints] = useState('');
    const [bets, setBets] = useState([]);
    const [gameType, setGameType] = useState('CLOSE');
    const navigate = useNavigate();
    const { marketName } = useParams();
    const { state } = useLocation();
    const marketId = state?.marketId || 1;  // Ensures marketId is correctly derived from state

    const panaNumbers = {
        0: ["127", "145", "190", "280", "370", "460", "550", "640", "703", "820", "901", "289"],
        1: ["136", "236", "245", "478", "568", "577", "589", "685", "784", "790", "820", "946"],
        2: ["138", "147", "156", "237", "246", "345", "589", "678", "765", "840", "906", "924"],
        3: ["129", "147", "156", "237", "246", "345", "489", "579", "678", "687", "759", "804"],
        4: ["139", "148", "157", "238", "247", "256", "346", "589", "670", "769", "859", "940"],
        5: ["149", "158", "167", "239", "248", "257", "347", "356", "419", "806", "815", "950"],
        6: ["123", "159", "168", "249", "258", "267", "348", "357", "456", "546", "723", "870"],
        7: ["124", "179", "269", "278", "359", "368", "458", "467", "557", "634", "709", "826"],
        8: ["125", "134", "189", "279", "369", "378", "459", "468", "567", "639", "738", "882"],
        9: ["126", "135", "189", "234", "279", "378", "459", "468", "567", "639", "738", "891"],
    };

    const getMarketAndGameType = () => {
        switch (marketName) {
            case 'Main Starline':
                return { table: 'sbids', marketIdField: 'starline', gameTypeId: 12 };
            case 'Main Jackpot':
                return { table: 'jbids', marketIdField: 'jackpot', gameTypeId: 12 };
            default:
                return { table: 'bids', marketIdField: 'market', gameTypeId: 12 };
        }
    };

    useEffect(() => {
        const fetchBalance = async () => {
            const userId = localStorage.getItem('user_id');
            const response = await axios.post('https://bhoom.miramatka.com/api/getBalanceApi.php', { user_id: userId });
            setBalance(response.data.balance);
        };
        fetchBalance();
    }, []);

    const handlePointsChange = (value) => {
        setPoints(value.replace(/[^0-9]/g, ''));
    };

    const placeBetForRow = (row) => {
        if (points) {
            const rowBets = panaNumbers[row].map(number => ({
                digit: number,
                points: parseInt(points, 10),
                type: gameType
            }));
            setBets(prevBets => [...prevBets, ...rowBets]);
        }
    };

    const handleRemoveBet = index => {
        setBets(bets.filter((_, i) => i !== index));
    };

    const totalBids = bets.length;
    const totalAmount = bets.reduce((sum, bet) => sum + bet.points, 0);

    const confirmSubmit = async () => {
        const userId = localStorage.getItem('user_id');
        const { table, marketIdField, gameTypeId } = getMarketAndGameType();

        const payload = {
            user_id: userId,
            game_type: gameTypeId,
            type: gameType.toLowerCase(),
            market_table: table,
            market_id_field: marketIdField,
            market_id: marketId,
            bids: bets,
            totalAmount,
            userbalance: balance - totalAmount,
            message: `${marketName ? marketName.toUpperCase() : 'UNKNOWN'} SINGLE PANNA BULK`,
        };

        try {
            const response = await axios.post('https://bhoom.miramatka.com/api/placeBet.php', payload);
            if (response.data.success) {
                setBalance(balance - totalAmount);
                setBets([]);
                setPoints('');
            } else {
                console.error('Error submitting bet:', response.data.message);
            }
        } catch (error) {
            console.error('Error submitting bet:', error);
        }
    };

    return (
        <div className="single-pana-bulk-container">
            <div className="header">
                <button className="back-button" onClick={() => navigate(-1)}>&#8592;</button>
                <h2>{marketName ? marketName.toUpperCase() : 'UNKNOWN'}, SINGLE PANNA BULK</h2>
                <div className="balance">
                    <img src="/assets/wallet_icon.png" alt="wallet" className="wallet-icon" /> ₹{balance}
                </div>
            </div>

            <div className="game-type-selector">
                <label>Select Game Type:</label>
                <select value={gameType} onChange={e => setGameType(e.target.value)}>
                    <option value="CLOSE">CLOSE</option>
                    <option value="OPEN">OPEN</option>
                </select>
            </div>

            <div className="points-input">
                <label>Enter Points:</label>
                <input
                    type="number"
                    placeholder="Enter points"
                    value={points}
                    onChange={e => handlePointsChange(e.target.value)}
                />
            </div>

            <div className="row-selector">
                {Object.keys(panaNumbers).map(num => (
                    <button key={num} className="row-button" onClick={() => placeBetForRow(num)}>
                         {num}
                    </button>
                ))}
            </div>

            <div className="bet-list">
                {bets.map((bet, index) => (
                    <div key={index} className="bet-item">
                        <span>{bet.digit}</span>
                        <span>{bet.points}</span>
                        <span>{bet.type}</span>
                        <button className="remove-button" onClick={() => handleRemoveBet(index)}>🗑️</button>
                    </div>
                ))}
            </div>

            <div className="bottom-bar">
                <span>Bid {totalBids}</span>
                <span>Total ₹{totalAmount}</span>
                <button className="submit-button" onClick={confirmSubmit} disabled={totalAmount === 0}>
                    Submit
                </button>
            </div>
        </div>
    );
};

export default SinglePanaBulk;
