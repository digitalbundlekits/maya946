import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import '../styles/GroupJodi.css';

const GroupJodi = () => {
    const [balance, setBalance] = useState(0);
    const [inputDigit, setInputDigit] = useState('');
    const [points, setPoints] = useState('');
    const [gameType, setGameType] = useState('CLOSE'); // Default game type
    const [availableDigits, setAvailableDigits] = useState([]);
    const [bets, setBets] = useState([]);
    const [showReviewModal, setShowReviewModal] = useState(false);
    const navigate = useNavigate();
    const { marketName } = useParams();
    const { state } = useLocation();
    const marketId = state?.marketId || 1; // Default to 1 if market ID not provided in state

    const getMarketAndGameType = () => {
        if (marketName === 'Main Starline') {
            return { table: 'sbids', marketIdField: 'starline', marketId, gameTypeId: 17 }; // GameTypeId for Group Jodi in Main Starline
        }
        if (marketName === 'Main Jackpot') {
            return { table: 'jbids', marketIdField: 'jackpot', marketId, gameTypeId: 17 }; // GameTypeId for Group Jodi in Main Jackpot
        }
        return { table: 'bids', marketIdField: 'market', marketId, gameTypeId: 17 }; // Default for other markets
    };
    

    useEffect(() => {
        const fetchBalance = async () => {
            try {
                const userId = localStorage.getItem('user_id');
                const response = await axios.post('https://bhoom.miramatka.com/api/getBalanceApi.php', { user_id: userId });
                setBalance(response.data.balance);
            } catch (error) {
                console.error('Error fetching balance:', error);
            }
        };
        fetchBalance();
    }, []);

    const generateAvailableDigits = (digit) => {
        const base = parseInt(digit, 10) * 10;
        return Array.from({ length: 10 }, (_, i) => (base + i).toString().padStart(2, '0'));
    };

    const handleDigitInputChange = (value) => {
        const sanitizedValue = value.replace(/[^0-9]/g, ''); // Allow only numeric values
        setInputDigit(sanitizedValue);
        if (sanitizedValue.length === 1) {
            setAvailableDigits(generateAvailableDigits(sanitizedValue));
        } else {
            setAvailableDigits([]);
        }
    };

    const handleSelectDigit = (digit) => {
        setInputDigit(digit); // Set the input field to the selected digit
        setAvailableDigits([]); // Clear the list
    };

    const calculateGroupJodiNumbers = (selectedDigit) => {
        const targetSum = [...selectedDigit].reduce((sum, digit) => sum + parseInt(digit, 10), 0) % 10;
        const results = [];

        for (let i = 0; i <= 9; i++) {
            for (let j = 0; j <= 9; j++) {
                const sum = i + j;
                const lastDigit = sum % 10;
                if (lastDigit === targetSum) {
                    results.push(`${i}${j}`.padStart(2, '0'));
                }
            }
        }

        return results;
    };

    const handleAddBet = () => {
        if (!inputDigit || !points) {
            alert('Please select a digit and enter points!');
            return;
        }

        const jodiNumbers = calculateGroupJodiNumbers(inputDigit);

        const newBets = jodiNumbers.map((jodi) => ({
            digit: jodi,
            points: parseInt(points, 10),
            type: gameType, // Include the selected game type
        }));

        setBets((prevBets) => [...prevBets, ...newBets]);
        setInputDigit('');
        setPoints('');
    };

    const handleRemoveBet = (index) => {
        setBets((prevBets) => prevBets.filter((_, i) => i !== index));
    };

    const calculateTotalPoints = () => bets.reduce((sum, bet) => sum + bet.points, 0);

    const confirmSubmit = async () => {
        const { table, marketIdField, gameTypeId } = getMarketAndGameType(); // Fetch market-specific values
        const payload = {
            user_id: localStorage.getItem('user_id'),
            game_type: gameTypeId, // Use the gameTypeId from getMarketAndGameType
            type: gameType.toLowerCase(),
            market_table: table,
            market_id_field: marketIdField,
            market_id: marketId,
            bids: bets,
            totalAmount: calculateTotalPoints(),
            userbalance: balance - calculateTotalPoints(),
            message: `${marketName ? marketName.toUpperCase() : 'UNKNOWN'} GROUP JODI`,
        };
    
        try {
            const response = await axios.post('https://bhoom.miramatka.com/api/placeBet.php', payload);
            if (response.data.success) {
                setBalance((prevBalance) => prevBalance - calculateTotalPoints());
                setBets([]); // Clear bets after submission
                setShowReviewModal(false);
            } else {
                console.error('Error submitting bets:', response.data.message);
            }
        } catch (error) {
            console.error('Error submitting bets:', error);
        }
    };
    

    return (
        <div className="group-jodi-container">
            <div className="header">
                <button className="back-button" onClick={() => navigate(-1)}>&#8592;</button>
                <h2>{marketName ? marketName.toUpperCase() : 'UNKNOWN'}, GROUP JODI</h2>
                <div className="balance">
                    <img src="/assets/wallet_icon.png" alt="wallet" className="wallet-icon" /> ₹{balance}
                </div>
            </div>

            <div className="inputs">
                <div className="input-group">
                    <label>Enter Digit:</label>
                    <input
                        type="text"
                        value={inputDigit}
                        maxLength={2}
                        onChange={(e) => handleDigitInputChange(e.target.value)}
                        placeholder="Enter a single digit (0-9)"
                    />
                </div>
                {availableDigits.length > 0 && (
                    <div className="digit-selector">
                        {availableDigits.map((digit) => (
                            <div
                                key={digit}
                                className="digit-option"
                                onClick={() => handleSelectDigit(digit)}
                            >
                                {digit}
                            </div>
                        ))}
                    </div>
                )}
                <div className="input-group">
                    <label>Enter Points:</label>
                    <input
                        type="text"
                        value={points}
                        onChange={(e) => setPoints(e.target.value.replace(/[^0-9]/g, ''))}
                        placeholder="Enter points"
                    />
                </div>
                <div className="input-group">
                    <label>Select Game Type:</label>
                    <select value={gameType} onChange={(e) => setGameType(e.target.value)}>
                        <option value="CLOSE">CLOSE</option>
                        <option value="OPEN">OPEN</option>
                    </select>
                </div>
                <button className="add-bid-button" onClick={handleAddBet}>
                    ADD BID
                </button>
            </div>

            <table className="bids-table">
                <thead>
                    <tr>
                        <th>Digit</th>
                        <th>Points</th>
                        <th>Type</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {bets.map((bet, index) => (
                        <tr key={index}>
                            <td>{bet.digit}</td>
                            <td>{bet.points}</td>
                            <td>{bet.type}</td>
                            <td>
                                <button className="delete-button" onClick={() => handleRemoveBet(index)}>
                                    🗑
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            <div className="bottom-bar">
                <span>Bid {bets.length}</span>
                <span>Total ₹{calculateTotalPoints()}</span>
                <button
                    className="submit-button"
                    onClick={() => setShowReviewModal(true)}
                    disabled={bets.length === 0}
                >
                    Submit
                </button>
            </div>

            {showReviewModal && (
                <div className="modal-overlay">
                    <div className="review-modal">
                        <h3>Review Bets</h3>
                        <table>
                            <thead>
                                <tr>
                                    <th>Digit</th>
                                    <th>Points</th>
                                    <th>Type</th>
                                </tr>
                            </thead>
                            <tbody>
                                {bets.map((bet, index) => (
                                    <tr key={index}>
                                        <td>{bet.digit}</td>
                                        <td>{bet.points}</td>
                                        <td>{bet.type}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        <div className="review-summary">
                            <p>Total Bids: {bets.length}</p>
                            <p>Total Bid Points: {calculateTotalPoints()}</p>
                            <p>Point Balance Before Game Play: ₹{balance}</p>
                            <p>Point Balance After Game Play: ₹{balance - calculateTotalPoints()}</p>
                            <p style={{ color: 'red' }}>Note: Bid Once Played Cannot Be Cancelled</p>
                        </div>
                        <div className="modal-buttons">
                            <button className="cancel-button" onClick={() => setShowReviewModal(false)}>
                                Cancel
                            </button>
                            <button className="confirm-button" onClick={confirmSubmit}>
                                Submit
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default GroupJodi;
