import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../styles/SingleDigits.css';
import { useNavigate, useParams, useLocation } from 'react-router-dom';

const SingleDigits = () => {
    const [balance, setBalance] = useState(0);
    const [amounts, setAmounts] = useState(Array(10).fill(''));
    const [gameType, setGameType] = useState('CLOSE');
    const [showReviewModal, setShowReviewModal] = useState(false);
    const [reviewData, setReviewData] = useState({});
    const navigate = useNavigate();
    const { marketName } = useParams();
    const { state } = useLocation();
    const marketId = state?.marketId || 1;  // Ensure marketId is properly sourced from state

    // Determine the appropriate table and fields based on the market name
    const getMarketAndGameType = () => {
        if (marketName === 'Main Starline') {
            return { table: 'sbids', marketIdField: 'starline', marketId, gameTypeId: 9 };
        }
        if (marketName === 'Main Jackpot') {
            return { table: 'jbids', marketIdField: 'jackpot', marketId, gameTypeId: 9 };
        }
        return { table: 'bids', marketIdField: 'market', marketId, gameTypeId: 9 }; // Default for other markets
    };

    useEffect(() => {
        const fetchBalance = async () => {
            try {
                const userId = localStorage.getItem('user_id');
                const response = await axios.post('https://bhoom.miramatka.com/api/getBalanceApi.php', { user_id: userId });
                setBalance(response.data.balance);
            } catch (error) {
                console.error('Error fetching balance:', error);
            }
        };
        fetchBalance();
    }, []);

    const handleAmountChange = (index, value) => {
        const updatedAmounts = [...amounts];
        updatedAmounts[index] = value.replace(/[^0-9]/g, '');
        setAmounts(updatedAmounts);
    };

    const totalBids = amounts.filter((amount) => amount).length;
    const totalAmount = amounts.reduce((sum, amount) => sum + (parseInt(amount) || 0), 0);

    const handleSubmit = () => {
        setShowReviewModal(true);
        setReviewData({
            bids: amounts.map((amount, index) => amount && { digit: index, points: parseInt(amount), type: gameType }).filter(Boolean),
            totalBids,
            totalAmount,
            balanceBefore: balance,
            balanceAfter: balance - totalAmount,
        });
    };

    const confirmSubmit = async () => {
        try {
            const userId = localStorage.getItem('user_id');
            const { table, marketIdField, gameTypeId } = getMarketAndGameType();

            const response = await axios.post('https://bhoom.miramatka.com/api/placeBet.php', {
                user_id: userId,
                game_type: gameTypeId,
                type: gameType.toLowerCase(),
                market_table: table,
                market_id_field: marketIdField,
                market_id: marketId,
                bids: reviewData.bids,
                totalAmount,
                userbalance: balance - totalAmount,
                message: `${marketName ? marketName.toUpperCase() : 'UNKNOWN'} SINGLE`,
            });

            if (response.data.success) {
                setBalance(prevBalance => prevBalance - totalAmount);
                setAmounts(Array(10).fill(''));
                setShowReviewModal(false);
            } else {
                console.error('Bid submission failed:', response.data.message);
            }
        } catch (error) {
            console.error('Error submitting bid:', error);
        }
    };

    return (
        <div className="single-digits-container">
            <div className="header">
                <button className="back-button" onClick={() => navigate(-1)}>&#8592;</button>
                <h2>{marketName ? marketName.toUpperCase() : 'UNKNOWN'}, SINGLE</h2>
                <div className="balance">
                    <img src="/assets/wallet_icon.png" alt="wallet" className="wallet-icon" /> ₹{balance}
                </div>
            </div>

            <div className="game-type-selector">
                <label>Select Game Type: </label>
                <select value={gameType} onChange={(e) => setGameType(e.target.value)}>
                    <option value="CLOSE">CLOSE</option>
                    <option value="OPEN">OPEN</option>
                </select>
            </div>

            <div className="digit-inputs">
                {amounts.map((amount, index) => (
                    <div key={index} className="digit-input">
                        <span className="digit-label">{index}</span>
                        <input
                            type="text"
                            placeholder="Enter amount"
                            value={amount}
                            onChange={(e) => handleAmountChange(index, e.target.value)}
                        />
                    </div>
                ))}
            </div>

            <div className="bottom-bar">
                <span>Bid: {totalBids}</span>
                <span>Total: ₹{totalAmount}</span>
                <button className="submit-button" onClick={handleSubmit} disabled={totalAmount === 0}>
                    Submit
                </button>
            </div>

            {showReviewModal && (
                <div className="modal-overlay">
                    <div className="review-modal">
                        <h3>Review Bets</h3>
                        <table>
                            <thead>
                                <tr>
                                    <th>Digit</th>
                                    <th>Points</th>
                                    <th>Type</th>
                                </tr>
                            </thead>
                            <tbody>
                                {reviewData.bids.map((bid, index) => (
                                    <tr key={index}>
                                        <td>{bid.digit}</td>
                                        <td>{bid.points}</td>
                                        <td>{bid.type}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        <div className="review-summary">
                            <p>Total Bids: {reviewData.totalBids}</p>
                            <p>Total Bid Points: {reviewData.totalAmount}</p>
                            <p>Point Balance Before Game Play: ₹{reviewData.balanceBefore}</p>
                            <p>Point Balance After Game Play: ₹{reviewData.balanceAfter}</p>
                            <p style={{ color: 'red' }}>Note: Bid Once Played Cannot Be Cancelled</p>
                        </div>
                        <div className="modal-buttons">
                            <button onClick={() => setShowReviewModal(false)} className="cancel-button">Cancel</button>
                            <button onClick={confirmSubmit} className="confirm-button">Submit</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default SingleDigits;
