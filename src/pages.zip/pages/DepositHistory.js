import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Header from '../components/Header';
import BottomNav from '../components/BottomNav';
import '../styles/Passbook.css';

const Deposit = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const userId = localStorage.getItem('user_id'); // Fetch the logged-in user's ID

  useEffect(() => {
    const fetchDepositData = async () => {
      try {
        const response = await axios.get(`https://bhoom.miramatka.com/api/getDepositData.php?userid=${userId}`);
        if (response.data.success) {
          setTransactions(response.data.data);
        } else {
          setError(response.data.message || 'Failed to fetch Deposit data');
        }
      } catch (error) {
        setError('An error occurred while fetching Deposit data');
      } finally {
        setLoading(false);
      }
    };

    fetchDepositData();
  }, [userId]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div className="error">{error}</div>;
  }

  return (
    <div className="passbook-page">
      <Header />
      <div className="passbook-container">
        {transactions.length > 0 ? (
          <table className="passbook-table">
            <thead>
              <tr>
               
                <th>Amount</th>
                <th>Message</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((transaction, index) => (
                <tr key={index}>
                  
                  <td>₹{transaction.amount.toFixed(2)}</td>
                  <td>{transaction.message || '-'}</td>
                  <td>{new Date(transaction.dt).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="no-transactions">No transactions found</div>
        )}
      </div>
      <BottomNav />
    </div>
  );
};

export default Deposit;
