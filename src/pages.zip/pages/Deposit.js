import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../styles/Deposit.css';

const Deposit = () => {
  const [amount, setAmount] = useState('');
  const [balance, setBalance] = useState(0);
  const predefinedAmounts = [800, 2000, 6000, 18000, 25000, 40000];
  const navigate = useNavigate();

  const userId = localStorage.getItem('user_id');

  useEffect(() => {
    const fetchBalance = async () => {
      try {
        const response = await axios.post('https://bhoom.miramatka.com/api/getBalanceApi.php', {
          user_id: userId,
        });
        if (response.data.success) {
          setBalance(response.data.balance);
        } else {
          console.error('Failed to fetch balance:', response.data.message);
        }
      } catch (error) {
        console.error('Error fetching balance:', error);
      }
    };

    fetchBalance();
  }, [userId]);

  const handleRecharge = async () => {
    if (amount < 500 || amount > 100000) {
      alert('Please enter an amount between ₹500 and ₹100000');
      return;
    }

    try {
      const response = await axios.post('https://bhoom.miramatka.com/api/create-order.php', {
        order_id: `ORD${Date.now()}`,
        txn_amount: amount,
        txn_note: 'Recharge Amount',
        product_name: 'Wallet Recharge',
        customer_name: 'Test User',
        customer_mobile: '9999999999',
        customer_email: 'testuser@gmail.com',
        redirect_url: 'http://localhost:3000/payment-status',
      });

      if (response.data.status) {
        const { payment_url } = response.data.results;
        window.location.href = payment_url; // Redirect to payment URL
      } else {
        alert(response.data.message);
      }
    } catch (error) {
      console.error('Error creating order:', error);
      alert('Failed to initiate payment. Please try again.');
    }
  };

  const handlePredefinedAmountClick = (amt) => {
    setAmount(amt);
  };

  return (
    <div className="deposit-container">
      <div className="header">
        <button className="back-button" onClick={() => navigate(-1)}>
          &#8592;
        </button>
        <h2>Recharge</h2>
      </div>

      <div className="balance-section">
        <p className="balance-label">Balance</p>
        <p className="balance-amount">₹{balance.toFixed(2)}</p>
      </div>

      <div className="amount-section">
        <label htmlFor="custom-amount" className="amount-label">Amount</label>
        <input
          type="number"
          id="custom-amount"
          className="amount-input"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="₹ 500 ~ ₹100000"
        />
      </div>

      <div className="predefined-amounts">
        {predefinedAmounts.map((amt, index) => (
          <button
            key={index}
            className={`amount-button ${parseInt(amount) === amt ? 'selected' : ''}`}
            onClick={() => handlePredefinedAmountClick(amt)}
          >
            ₹{amt}
          </button>
        ))}
      </div>

      <button
        className="recharge-button"
        onClick={handleRecharge}
        disabled={!amount || isNaN(amount) || parseInt(amount) < 500 || parseInt(amount) > 100000}
      >
        Recharge
      </button>

      
    </div>
  );
};

export default Deposit;
