import React, { useEffect, useState } from 'react';
import axios from 'axios';
import '../styles/Jackpot.css';
import { useNavigate } from 'react-router-dom';

// Utility function to format time in 12-hour format with AM/PM
const formatTime12Hour = (timeStr) => {
    const [hours, minutes] = timeStr.split(':').map(Number);
    const date = new Date();
    date.setHours(hours, minutes, 0);

    return new Intl.DateTimeFormat('en-US', {
        hour: 'numeric',
        minute: 'numeric',
        hour12: true,
        timeZone: 'Asia/Kolkata',
    }).format(date);
};

// Determine game status (running/open/closed) based on start and end times
const determineStatus = (stime, etime, now) => {
    const startTime = new Date(now);
    const endTime = new Date(now);

    const [startHours, startMinutes] = stime.split(':').map(Number);
    const [endHours, endMinutes] = etime.split(':').map(Number);

    startTime.setHours(startHours, startMinutes, 0);
    endTime.setHours(endHours, endMinutes, 0);

    if (now >= startTime && now <= endTime) return 'running';
    if (now < startTime) return 'open';
    return 'closed';
};

const Jackpot = () => {
    const [games, setGames] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchGames = async () => {
            try {
                const response = await axios.get('https://bhoom.miramatka.com/api/getJackpotGames.php');
                if (response.data.success) {
                    const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));

                    // Map games with statuses and formatted start times
                    const fetchedGames = response.data.games.map((game) => ({
                        ...game,
                        result: game.result === '**' ? '**' : game.result, // Update default result format
                        status: determineStatus(game.stime, game.etime, now),
                        formattedStartTime: formatTime12Hour(game.stime),
                    }));

                    // Sort games: running first, then open, then closed
                    const sortedGames = fetchedGames.sort((a, b) => {
                        if (a.status === 'running' && b.status !== 'running') return -1;
                        if (a.status !== 'running' && b.status === 'running') return 1;
                        if (a.status === 'open' && b.status === 'closed') return -1;
                        if (a.status === 'closed' && b.status === 'open') return 1;
                        return 0;
                    });

                    setGames(sortedGames);
                }
            } catch (error) {
                console.error('Error fetching jackpot games:', error);
            }
        };
        fetchGames();
    }, []);

    const handlePlayGame = (marketId) => {
        navigate(`/gameOptions/Main Jackpot`, { state: { marketName: 'Main Jackpot', marketId } });
    };

    return (
        <div className="jackpot-container">
            {/* Header Section */}
            <div className="jackpot-header">
                <button className="jackpot-back-button" onClick={() => navigate(-1)}>
                    &#8592;
                </button>
                <h2>Jackpot Games</h2>
            </div>

            {/* Games List */}
            <div className="jackpot-games-list">
                {games.map((game) => (
                    <div key={game.market_id} className="jackpot-game-card">
                        <div className="jackpot-card-top">
                            <div className="jackpot-time">
                                {game.formattedStartTime}
                            </div>
                            <div className="jackpot-clock-icon">
                                ⏰
                            </div>
                        </div>
                        <div className="jackpot-result">{game.result || '***-**-***'}</div>
                        <div className={`jackpot-status ${game.status}`}>
                            {game.status === 'running'
                                ? 'Running'
                                : game.status === 'open'
                                ? 'Open'
                                : 'Closed for Today'}
                        </div>
                        <button
                            className="jackpot-play-button"
                            onClick={() => handlePlayGame(game.market_id)}
                            disabled={game.status === 'closed'}
                        >
                            ▶ Play Game
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Jackpot;
