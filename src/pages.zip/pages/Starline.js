import React, { useEffect, useState } from 'react';
import axios from 'axios';
import '../styles/Starline.css';
import { useNavigate } from 'react-router-dom';

// Utility function to format time in 12-hour format with AM/PM
const formatTime12Hour = (timeStr) => {
    const [hours, minutes] = timeStr.split(':').map(Number);
    const date = new Date();
    date.setHours(hours, minutes, 0);

    return new Intl.DateTimeFormat('en-US', {
        hour: 'numeric',
        minute: 'numeric',
        hour12: true,
        timeZone: 'Asia/Kolkata',
    }).format(date);
};

// Determine game status (running/open/closed) based on start and end times
const determineStatus = (stime, etime, now) => {
    const startTime = new Date(now);
    const endTime = new Date(now);

    const [startHours, startMinutes] = stime.split(':').map(Number);
    const [endHours, endMinutes] = etime.split(':').map(Number);

    startTime.setHours(startHours, startMinutes, 0);
    endTime.setHours(endHours, endMinutes, 0);

    if (now >= startTime && now <= endTime) return 'running';
    if (now < startTime) return 'open';
    return 'closed';
};

const Starline = () => {
    const [games, setGames] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchGames = async () => {
            try {
                const response = await axios.get('https://bhoom.miramatka.com/api/getStarlineGames.php');
                if (response.data.success) {
                    const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));

                    const fetchedGames = response.data.games.map((game) => ({
                        ...game,
                        status: determineStatus(game.stime, game.etime, now),
                        formattedStartTime: formatTime12Hour(game.stime),
                    }));

                    // Sort games so "running" games appear first
                    const sortedGames = fetchedGames.sort((a, b) => {
                        if (a.status === 'running' && b.status !== 'running') return -1;
                        if (a.status !== 'running' && b.status === 'running') return 1;
                        if (a.status === 'open' && b.status === 'closed') return -1;
                        if (a.status === 'closed' && b.status === 'open') return 1;
                        return 0;
                    });

                    setGames(sortedGames);
                }
            } catch (error) {
                console.error('Error fetching starline games:', error);
            }
        };

        fetchGames();
    }, []);

    const handlePlayGame = (marketId) => {
        navigate(`/gameOptions/Main Starline`, { state: { marketName: 'Main Starline', marketId } });
    };

    return (
        <div className="starline-container">
            {/* Header Section */}
            <div className="header">
                <button className="back-button" onClick={() => navigate(-1)}>
                    &#8592;
                </button>
                <h2>Starline Games</h2>
            </div>

            {/* Games List */}
            <div className="games-list">
                {games.map((game) => (
                    <div key={game.market_id} className="game-item">
                        {/* Left Section */}
                        <div className="game-left">
                            <div className="game-time">
                                <span className="clock-icon">⏰</span>
                                <span>{game.formattedStartTime}</span>
                            </div>
                            <div className={`game-status ${game.status}`}>
                                {game.status === 'running'
                                    ? 'Market Running'
                                    : game.status === 'open'
                                    ? 'Market Open'
                                    : 'Closed for Today'}
                            </div>
                        </div>

                        {/* Right Section */}
                        <div className="game-right">
                            <button
                                className="play-button"
                                onClick={() => handlePlayGame(game.market_id)}
                                disabled={game.status === 'closed'}
                            >
                                ▶
                            </button>
                            <span className="play-text">Play Game</span>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Starline;
